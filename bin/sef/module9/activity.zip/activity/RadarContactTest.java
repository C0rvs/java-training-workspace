package sef.module9.activity;

import junit.framework.TestCase;

public class RadarContactTest extends TestCase {
	
	RadarContactTest1 runTest = new RadarContactTest1();
	
	public void testRadarContactPostiveBearing(){
		runTest.testRadarContactPostiveBearing();	
	}
	
	public void testRadarContactNegativeBearing(){
		runTest.testRadarContactNegativeBearing();	
	}

}
